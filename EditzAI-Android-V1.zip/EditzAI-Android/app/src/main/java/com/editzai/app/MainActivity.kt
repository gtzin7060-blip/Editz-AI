package com.editzai.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF08070D)
private val Panel = Color(0xFF15111F)
private val Purple = Color(0xFF9B5CFF)
private val PurpleBright = Color(0xFFB78AFF)
private val Muted = Color(0xFFAAA2B8)

enum class EditStyle(val title: String, val subtitle: String) {
    VELOCITY("Velocity", "Cortes rápidos e ritmo"),
    SHAKE("Shake", "Movimento e impacto"),
    GLOW("Glow", "Brilho e destaque"),
    FLASH("Flash", "Transições luminosas"),
    CINEMATIC("Cinematic", "Visual dramático")
}

enum class AspectRatio(val label: String) {
    VERTICAL("9:16"), SQUARE("1:1"), LANDSCAPE("16:9")
}

enum class ExportQuality(val label: String) {
    HD("1080p · 60 FPS"), FOUR_K("4K · 60 FPS")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EditzAiApp() }
    }
}

@Composable
fun EditzAiApp() {
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf<String?>(null) }
    var selectedStyle by remember { mutableStateOf(EditStyle.VELOCITY) }
    var selectedRatio by remember { mutableStateOf(AspectRatio.VERTICAL) }
    var selectedQuality by remember { mutableStateOf(ExportQuality.HD) }
    var showInfo by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "Vídeo selecionado"
        }
    }

    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = PurpleBright,
            background = Background,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Background) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Spacer(Modifier.height(16.dp))
                Header()
                HeroCard()
                SectionTitle("SEU VÍDEO")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = PurpleBright)
                            Text(
                                text = videoName ?: "Nenhum vídeo selecionado",
                                modifier = Modifier.weight(1f).padding(start = 10.dp),
                                color = if (videoName == null) Muted else Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (videoUri != null) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Selecionado", tint = Color(0xFF7BE0A1))
                            }
                        }
                        OutlinedButton(
                            onClick = { picker.launch(arrayOf("video/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PurpleBright)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Text("  Escolher vídeo")
                        }
                    }
                }

                SectionTitle("ESTILO DA EDIT")
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        StyleCard(EditStyle.VELOCITY, selectedStyle == EditStyle.VELOCITY, Modifier.weight(1f)) { selectedStyle = it }
                        StyleCard(EditStyle.SHAKE, selectedStyle == EditStyle.SHAKE, Modifier.weight(1f)) { selectedStyle = it }
                        StyleCard(EditStyle.GLOW, selectedStyle == EditStyle.GLOW, Modifier.weight(1f)) { selectedStyle = it }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        StyleCard(EditStyle.FLASH, selectedStyle == EditStyle.FLASH, Modifier.weight(1f)) { selectedStyle = it }
                        StyleCard(EditStyle.CINEMATIC, selectedStyle == EditStyle.CINEMATIC, Modifier.weight(1f)) { selectedStyle = it }
                    }
                }

                SectionTitle("FORMATO")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AspectRatio.entries.forEach { ratio ->
                        ChoiceChip(ratio.label, selectedRatio == ratio, Modifier.weight(1f)) { selectedRatio = ratio }
                    }
                }

                SectionTitle("QUALIDADE")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExportQuality.entries.forEach { quality ->
                        ChoiceChip(quality.label, selectedQuality == quality, Modifier.weight(1f)) { selectedQuality = quality }
                    }
                }

                Button(
                    onClick = { showInfo = true },
                    enabled = videoUri != null,
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Purple,
                        disabledContainerColor = Color(0xFF352A46)
                    )
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Text("  GERAR EDIT COM IA", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
                Text(
                    "Dica: use vídeos que você tem direito de editar e compartilhar.",
                    color = Muted,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            containerColor = Panel,
            title = { Text("Motor de IA ainda não conectado") },
            text = {
                Text(
                    "A interface e a seleção do vídeo já estão prontas. Para gerar a edit automaticamente, falta conectar o backend de IA e o renderizador de vídeo.\n\n" +
                    "Configuração escolhida: ${selectedStyle.title}, ${selectedRatio.label}, ${selectedQuality.label}.",
                    color = Muted
                )
            },
            confirmButton = {
                TextButton(onClick = { showInfo = false }) { Text("Entendi", color = PurpleBright) }
            }
        )
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            modifier = Modifier.size(43.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(Purple, Color(0xFF5525A8)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.SportsSoccer, contentDescription = null, tint = Color.White, modifier = Modifier.size(25.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text("EDITZ AI", fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text("FOOTBALL EDIT STUDIO", fontSize = 9.sp, color = PurpleBright, letterSpacing = 2.sp)
        }
        Box(
            modifier = Modifier.clip(CircleShape).background(Color(0xFF241936)).padding(horizontal = 11.dp, vertical = 6.dp)
        ) { Text("V1.0", color = PurpleBright, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun HeroCard() {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF32165A), Color(0xFF171022), Color(0xFF10101A))))
            .border(1.dp, Color(0xFF583486), RoundedCornerShape(22.dp))
            .padding(19.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("TRANSFORME LANCES EM EDITS", color = PurpleBright, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("Sua edit começa
com um vídeo.", fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("A IA vai cuidar dos cortes, efeitos e ritmo.", color = Muted, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = PurpleBright)
                Text("FEITO PARA FUTEBOL", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = PurpleBright, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
}

@Composable
private fun StyleCard(style: EditStyle, selected: Boolean, modifier: Modifier, onClick: (EditStyle) -> Unit) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(14.dp))
            .background(if (selected) Color(0xFF2A1B40) else Panel)
            .border(1.dp, if (selected) Purple else Color(0xFF30283A), RoundedCornerShape(14.dp))
            .clickable { onClick(style) }.padding(11.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(style.title, color = if (selected) PurpleBright else Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(style.subtitle, color = Muted, fontSize = 9.sp, lineHeight = 12.sp)
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(12.dp))
            .background(if (selected) Color(0xFF2A1B40) else Panel)
            .border(1.dp, if (selected) Purple else Color(0xFF30283A), RoundedCornerShape(12.dp))
            .clickable { onClick() }.padding(vertical = 12.dp, horizontal = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) PurpleBright else Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
