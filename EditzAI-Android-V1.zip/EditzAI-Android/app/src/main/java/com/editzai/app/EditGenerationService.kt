package com.editzai.app

/**
 * Contrato para conectar o backend de IA e o motor de renderização.
 *
 * A implementação real deve enviar o vídeo para um backend seguro,
 * receber o plano de edição e renderizar/baixar o MP4 final.
 * Nunca coloque tokens ou chaves privadas dentro do aplicativo Android.
 */
interface EditGenerationService {
    suspend fun generate(request: EditRequest): GenerationResult
}

data class EditRequest(
    val videoUri: String,
    val style: EditStyle,
    val aspectRatio: AspectRatio,
    val quality: ExportQuality
)

sealed interface GenerationResult {
    data class Success(val outputUri: String) : GenerationResult
    data class Failure(val message: String) : GenerationResult
}
