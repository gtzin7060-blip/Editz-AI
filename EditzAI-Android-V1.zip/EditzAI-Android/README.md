# Editz AI V1 — Android

Projeto inicial nativo Android em Kotlin + Jetpack Compose, com identidade visual preto/roxo neon.

## O que já está implementado
- Tela inicial do Editz AI.
- Importação de vídeo pela galeria/arquivos do Android (URI de conteúdo).
- Seleção de estilo: Velocity, Shake, Glow, Flash e Cinematic.
- Seleção de formato e qualidade de exportação.
- Validação básica antes de iniciar uma geração.
- Camada `EditGenerationService` isolada para conectar um motor de edição/IA real.

## Importante sobre a IA
Esta V1 é a base funcional do aplicativo e da interface. A geração automática real ainda precisa de um serviço de IA/backend e de um motor de renderização de vídeo. O app não finge que já gerou uma edit: ao tocar em “Gerar edit”, ele informa que a conexão do motor ainda precisa ser configurada.

Para transformar isso em geração real, a próxima etapa é implementar:
1. Backend seguro (não colocar chaves de API dentro do APK).
2. Serviço que analise os vídeos e selecione momentos/cortes.
3. Motor de renderização que aplique cortes, efeitos, música e exporte o MP4.
4. Download/compartilhamento do resultado no Android.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `EditzAI-Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em um celular Android ou emulador (Android 8.0 / API 26 ou superior).

Requisitos: Android Studio recente e JDK 17.

## Estrutura
- `app/src/main/java/com/editzai/app/MainActivity.kt`: interface e fluxo inicial.
- `app/src/main/java/com/editzai/app/EditGenerationService.kt`: contrato para o futuro serviço de IA.
